package com.Hotcer;

public class Coche {
  //atributos//
  int numeroP=0;

public  void incrementaP(){
  this.numeroP++;
}

}
